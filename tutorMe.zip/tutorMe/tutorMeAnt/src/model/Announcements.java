/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


import java.util.ArrayList;

/**
 *
 * @author parth
 */
public class Announcements {
    public ArrayList <String> announcements;
    
    public ArrayList <String> getAnnouncements(){
        return announcements;
    }
    
    private void setAnnouncements(ArrayList <String> a){
        announcements =a ;
    }
    
}
